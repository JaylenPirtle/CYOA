let runIt = function(){
  let userFood = getFoodSelection

  document.getElementById("output").innerHTML = "You Like " + userFood + " Favorite foods you're intrested in";
}

